# Amperka Software and Drivers

Version: 0.1.2<br>

add to arduino IDE:

https://raw.githubusercontent.com/amperka/iskra-boards/master/package_amperka_index.json
